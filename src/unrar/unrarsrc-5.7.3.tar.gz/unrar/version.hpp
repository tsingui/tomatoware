#define RARVER_MAJOR     5
#define RARVER_MINOR    70
#define RARVER_BETA      0
#define RARVER_DAY      25
#define RARVER_MONTH     2
#define RARVER_YEAR   2019
